$(window).scroll(function () {
var scroll = $(window).scrollTop();
if (scroll < 100) {
$('.fixed-top').css({
"background": "transparent",
"box-shadow": "none"
});
} else {
$('.fixed-top').css({
"background": "#fff",
"box-shadow": "9px 8px 15px -1px rgb(0 0 0 / 10%)"

});
}





});


